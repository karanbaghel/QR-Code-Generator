import React, { useState, useRef } from 'react';
import QRCode from 'qrcode.react';

function EmailForm() {
  const [emailInfo, setEmailInfo] = useState({ to: '', subject: '', body: '' });
  const qrRef = useRef();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setEmailInfo({ ...emailInfo, [name]: value });
  };

  const handleClear = () => {
    setEmailInfo({ to: '', subject: '', body: '' });
  };

  const generateQrValue = () => {
    return `mailto:${emailInfo.to}?subject=${encodeURIComponent(emailInfo.subject)}&body=${encodeURIComponent(emailInfo.body)}`;
  };

  const handleDownload = () => {
    const canvas = qrRef.current.querySelector('canvas');
    const pngUrl = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
    let downloadLink = document.createElement('a');
    downloadLink.href = pngUrl;
    downloadLink.download = 'email_qrcode.png';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  return (
    <div className="container my-4">
      <h1 className="text-center mb-4">Email Information and QR Code Generator</h1>
      <form className="row justify-content-center">
        <div className="col-md-6">
          <div className="form-group mb-3">
            <label htmlFor="to" className="form-label">To</label>
            <input
              type="email"
              id="to"
              name="to"
              placeholder="To"
              value={emailInfo.to}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          <div className="form-group mb-3">
            <label htmlFor="subject" className="form-label">Subject</label>
            <input
              type="text"
              id="subject"
              name="subject"
              placeholder="Subject"
              value={emailInfo.subject}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          <div className="form-group mb-3">
            <label htmlFor="body" className="form-label">Body</label>
            <textarea
              id="body"
              name="body"
              placeholder="Body"
              value={emailInfo.body}
              onChange={handleChange}
              className="form-control"
              rows="4"
            />
          </div>
          <div className="d-flex justify-content-between mb-3">
            <button
              type="button"
              onClick={handleClear}
              className="btn btn-secondary"
            >
              Clear
            </button>
            <button
              type="button"
              onClick={handleDownload}
              className="btn btn-primary"
            >
              Download
            </button>
          </div>
          <div ref={qrRef} className="border p-3 d-flex justify-content-center" aria-label="QR Code">
            <QRCode value={generateQrValue()} size={256} />
          </div>
        </div>
      </form>
    </div>
  );
}

export default EmailForm;
