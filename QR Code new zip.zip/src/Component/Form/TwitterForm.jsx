import React, { useState, useRef } from 'react';
import QRCode from 'qrcode.react';
import { Container, Row, Col, Form, FormGroup, Label, Input, Button } from 'reactstrap';

function TwitterForm() {
  const [twitterHandle, setTwitterHandle] = useState('');
  const qrRef = useRef();

  const handleChange = (event) => {
    setTwitterHandle(event.target.value);
  };

  const handleClear = () => {
    setTwitterHandle('');
  };

  const generateQrValue = () => {
    return `https://twitter.com/${twitterHandle}`;
  };

  const handleDownload = () => {
    const canvas = qrRef.current.querySelector('canvas');
    const pngUrl = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
    let downloadLink = document.createElement('a');
    downloadLink.href = pngUrl;
    downloadLink.download = 'twitter_qrcode.png';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  return (
    <Container className="py-5">
      <Row>
        <Col xs="12" md="8" lg="6" className="mx-auto">
          <h1 className="text-center mb-4">Twitter QR Code Generator</h1>
          <Form aria-labelledby="form-title">
            <FormGroup>
              <Label for="twitterHandle">Twitter Handle</Label>
              <Input
                type="text"
                id="twitterHandle"
                placeholder="Enter Twitter Handle"
                value={twitterHandle}
                onChange={handleChange}
                aria-label="Enter Twitter Handle"
              />
            </FormGroup>
            <Button color="secondary" onClick={handleClear} className="mb-3" aria-label="Clear the form">
              Clear
            </Button>
            <div ref={qrRef} className="border p-3 mb-3 text-center" aria-live="polite" aria-label="QR Code display">
              <QRCode value={generateQrValue()} size={256} />
            </div>
            <Button color="primary" onClick={handleDownload} aria-label="Download the QR code">
              Download
            </Button>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}

export default TwitterForm;
