import React, { useState, useRef } from 'react';
import QRCode from 'qrcode.react';
import { Container, Row, Col, Form, FormGroup, Label, Input, Button } from 'reactstrap';

function WifiForm() {
  const [wifiInfo, setWifiInfo] = useState({ ssid: '', password: '', encryption: 'WPA' });
  const qrRef = useRef();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setWifiInfo({ ...wifiInfo, [name]: value });
  };

  const handleClear = () => {
    setWifiInfo({ ssid: '', password: '', encryption: 'WPA' });
  };

  const generateQrValue = () => {
    return `WIFI:T:${wifiInfo.encryption};S:${wifiInfo.ssid};P:${wifiInfo.password};;`;
  };

  const handleDownload = () => {
    const canvas = qrRef.current.querySelector('canvas');
    const pngUrl = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
    let downloadLink = document.createElement('a');
    downloadLink.href = pngUrl;
    downloadLink.download = 'wifi_qrcode.png';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  return (
    <Container className="py-5">
      <Row>
        <Col xs="12" md="8" lg="6" className="mx-auto">
          <h1 className="text-center mb-4">WiFi QR Code Generator</h1>
          <Form aria-labelledby="form-title">
            <FormGroup>
              <Label for="ssid">SSID</Label>
              <Input
                type="text"
                id="ssid"
                name="ssid"
                placeholder="Enter SSID"
                value={wifiInfo.ssid}
                onChange={handleChange}
                aria-label="Enter SSID"
              />
            </FormGroup>
            <FormGroup>
              <Label for="password">Password</Label>
              <Input
                type="text"
                id="password"
                name="password"
                placeholder="Enter Password"
                value={wifiInfo.password}
                onChange={handleChange}
                aria-label="Enter Password"
              />
            </FormGroup>
            <FormGroup>
              <Label for="encryption">Encryption</Label>
              <Input
                type="select"
                id="encryption"
                name="encryption"
                value={wifiInfo.encryption}
                onChange={handleChange}
                aria-label="Select Encryption Type"
              >
                <option value="WPA">WPA/WPA2</option>
                <option value="WEP">WEP</option>
                <option value="nopass">No Password</option>
              </Input>
            </FormGroup>
            <Button color="secondary" onClick={handleClear} className="mb-3" aria-label="Clear the form">
              Clear
            </Button>
            <div ref={qrRef} className="border p-3 mb-3 text-center" aria-live="polite" aria-label="QR Code display">
              <QRCode value={generateQrValue()} size={256} />
            </div>
            <Button color="primary" onClick={handleDownload} aria-label="Download the QR code">
              Download
            </Button>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}

export default WifiForm;
