// import React, { useState, useRef } from 'react';
// import QRCode from 'qrcode.react';
// import 'bootstrap/dist/css/bootstrap.min.css';

// function UrlForm() {
//   const [url, setUrl] = useState('');
//   const qrRef = useRef();

//   const handleChange = (event) => {
//     setUrl(event.target.value);
//   };

//   const handleClear = () => {
//     setUrl('');
//   };

//   const handleDownload = () => {
//     const canvas = qrRef.current.querySelector('canvas');
//     const pngUrl = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
//     let downloadLink = document.createElement('a');
//     downloadLink.href = pngUrl;
//     downloadLink.download = 'qrcode.png';
//     document.body.appendChild(downloadLink);
//     downloadLink.click();
//     document.body.removeChild(downloadLink);
//   };

//   return (
//     <div className="container">
//       <div className="row justify-content-center">
//         <div className="col-lg-8 col-md-10 col-sm-12">
//           <div className="card shadow-sm p-4">
//             <h1 className="text-center mb-4">QR Code Generator for URL</h1>
//             <div className="row">
//               <div className="col-md-6">
//                 <form>
//                   <div className="form-group">
//                     <label htmlFor="urlInput" className="form-label">Enter URL</label>
//                     <input
//                       type="text"
//                       id="urlInput"
//                       placeholder="Enter URL"
//                       value={url}
//                       onChange={handleChange}
//                       className="form-control mb-3"
//                       aria-describedby="urlHelp"
//                     />
//                     <small id="urlHelp" className="form-text text-muted">Enter the URL you want to generate a QR code for.</small>
//                   </div>
//                 </form>
//                 <div className="d-flex justify-content-center mb-2">
//                   <button
//                     onClick={handleClear}
//                     className="btn btn-success me-2"
//                   >
//                     Clear
//                   </button>
//                   <button
//                     onClick={handleDownload}
//                     className="btn btn-primary"
//                   >
//                     Download
//                   </button>
//                 </div>
//               </div>
//               <div className="col-md-6 text-center">
//                 <div ref={qrRef} className="d-inline-block border p-3" aria-label="QR Code">
//                   <QRCode value={url || ' '} size={256} />
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default UrlForm;

import React, { useState, useRef, useEffect } from 'react';
import QRCode from 'qrcode.react';
import 'bootstrap/dist/css/bootstrap.min.css';

function UrlForm() {
  const [url, setUrl] = useState('');
  const qrRef = useRef();
  const [qrSize, setQrSize] = useState(256);

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      if (width < 576) {
        setQrSize(150); // Small screen size
      } else if (width < 768) {
        setQrSize(200); // Medium screen size
      } else {
        setQrSize(256); // Large screen size
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleChange = (event) => {
    setUrl(event.target.value);
  };

  const handleClear = () => {
    setUrl('');
  };

  const handleDownload = () => {
    const canvas = qrRef.current.querySelector('canvas');
    const pngUrl = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
    let downloadLink = document.createElement('a');
    downloadLink.href = pngUrl;
    downloadLink.download = 'qrcode.png';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-lg-8 col-md-10 col-sm-12">
          <h1 className="text-center mb-4">QR Code Generator for URL</h1>
          <div className="row">
            <div className="col-md-6 mb-3">
              <div className="card shadow-sm p-4 border">
                <form>
                  <div className="form-group">
                    <label htmlFor="urlInput" className="form-label">Enter URL</label>
                    <input
                      type="text"
                      id="urlInput"
                      placeholder="Enter URL"
                      value={url}
                      onChange={handleChange}
                      className="form-control mb-3"
                      aria-describedby="urlHelp"
                    />
                    <small id="urlHelp" className="form-text text-muted">Enter the URL you want to generate a QR code for.</small>
                  </div>
                </form>
                <div className="d-flex justify-content-center mb-2">
                  <button
                    onClick={handleClear}
                    className="btn btn-success me-2"
                  >
                    Clear
                  </button>
                  <button
                    onClick={handleDownload}
                    className="btn btn-primary"
                  >
                    Download
                  </button>
                </div>
              </div>
            </div>
            <div className="col-md-6 mb-3">
              <div className="card shadow-sm p-4 border text-center">
                <div ref={qrRef} className="d-inline-block border p-3" aria-label="QR Code">
                  <QRCode value={url || ' '} size={qrSize} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UrlForm;


