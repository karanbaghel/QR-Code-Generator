import React, { useState, useRef } from 'react';
import QRCode from 'qrcode.react';
import { Container, Row, Col, Form, FormGroup, Label, Input, Button } from 'reactstrap';

function VcardForm() {
  const [vcardInfo, setVcardInfo] = useState({ name: '', organization: '', phone: '', email: '', address: '' });
  const qrRef = useRef();

  const handleChange = (event) => {
    const { name, value } = event.target;
    setVcardInfo({ ...vcardInfo, [name]: value });
  };

  const handleClear = () => {
    setVcardInfo({ name: '', organization: '', phone: '', email: '', address: '' });
  };

  const generateQrValue = () => {
    return `BEGIN:VCARD\nVERSION:3.0\nN:${vcardInfo.name}\nORG:${vcardInfo.organization}\nTEL:${vcardInfo.phone}\nEMAIL:${vcardInfo.email}\nADR:${vcardInfo.address}\nEND:VCARD`;
  };

  const handleDownload = () => {
    const canvas = qrRef.current.querySelector('canvas');
    const pngUrl = canvas.toDataURL('image/png').replace('image/png', 'image/octet-stream');
    let downloadLink = document.createElement('a');
    downloadLink.href = pngUrl;
    downloadLink.download = 'vcard_qrcode.png';
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  };

  return (
    <Container className="py-5">
      <Row>
        <Col xs="12" md="8" lg="6" className="mx-auto">
          <h1 className="text-center mb-4">vCard QR Code Generator</h1>
          <Form aria-labelledby="form-title">
            <FormGroup>
              <Label for="name">Name</Label>
              <Input
                type="text"
                id="name"
                name="name"
                placeholder="Enter Name"
                value={vcardInfo.name}
                onChange={handleChange}
                aria-label="Enter Name"
              />
            </FormGroup>
            <FormGroup>
              <Label for="organization">Organization</Label>
              <Input
                type="text"
                id="organization"
                name="organization"
                placeholder="Enter Organization"
                value={vcardInfo.organization}
                onChange={handleChange}
                aria-label="Enter Organization"
              />
            </FormGroup>
            <FormGroup>
              <Label for="phone">Phone</Label>
              <Input
                type="text"
                id="phone"
                name="phone"
                placeholder="Enter Phone"
                value={vcardInfo.phone}
                onChange={handleChange}
                aria-label="Enter Phone"
              />
            </FormGroup>
            <FormGroup>
              <Label for="email">Email</Label>
              <Input
                type="email"
                id="email"
                name="email"
                placeholder="Enter Email"
                value={vcardInfo.email}
                onChange={handleChange}
                aria-label="Enter Email"
              />
            </FormGroup>
            <FormGroup>
              <Label for="address">Address</Label>
              <Input
                type="text"
                id="address"
                name="address"
                placeholder="Enter Address"
                value={vcardInfo.address}
                onChange={handleChange}
                aria-label="Enter Address"
              />
            </FormGroup>
            <Button color="secondary" onClick={handleClear} className="mb-3" aria-label="Clear the form">
              Clear
            </Button>
            <div ref={qrRef} className="border p-3 mb-3 text-center" aria-live="polite" aria-label="QR Code display">
              <QRCode value={generateQrValue()} size={256} />
            </div>
            <Button color="primary" onClick={handleDownload} aria-label="Download the QR code">
              Download
            </Button>
          </Form>
        </Col>
      </Row>
    </Container>
  );
}

export default VcardForm;
